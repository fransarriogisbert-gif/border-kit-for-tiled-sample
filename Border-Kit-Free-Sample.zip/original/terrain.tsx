<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" name="Demo" tilewidth="8" tileheight="6" tilecount="4" columns="2" margin="1" spacing="2">
 <image source="terrain.png" width="20" height="16"/>
 <tile id="0"><properties><property name="surface" value="stone"/></properties><objectgroup><object id="1" x="1" y="2" width="4" height="3"/></objectgroup></tile>
 <tile id="1"><animation><frame tileid="1" duration="120"/><frame tileid="2" duration="150"/></animation></tile>
</tileset>
